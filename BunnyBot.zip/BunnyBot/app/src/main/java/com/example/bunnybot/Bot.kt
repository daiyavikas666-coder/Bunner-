package com.example.bunnybot

import android.content.Context

/** Shared settings and live state. */
object Bot {
    @Volatile var enabled = false
    @Volatile var debug = true

    // Where the bunny sits on screen (fractions of width / height)
    @Volatile var ax = 0.45f
    @Volatile var ay = 0.72f
    // How far ahead of the bunny to look (fraction of screen width)
    @Volatile var look = 0.16f
    // Turn when less than this share of look-ahead points is still path
    @Volatile var thr = 0.4f
    // Minimum time between two taps
    @Volatile var cooldownMs = 250
    @Volatile var taps = 0

    /** state: 0 = not path (fence/grass), 1 = path, 2 = unknown (carrot etc.) */
    class Probe(val x: Float, val y: Float, val state: Int)
    @Volatile var probes: List<Probe> = emptyList()

    fun load(c: Context) {
        val p = c.getSharedPreferences("bot", Context.MODE_PRIVATE)
        ax = p.getFloat("ax", ax)
        ay = p.getFloat("ay", ay)
        look = p.getFloat("look", look)
        thr = p.getFloat("thr", thr)
        cooldownMs = p.getInt("cooldown", cooldownMs)
        debug = p.getBoolean("debug", debug)
    }

    fun save(c: Context) {
        c.getSharedPreferences("bot", Context.MODE_PRIVATE).edit()
            .putFloat("ax", ax)
            .putFloat("ay", ay)
            .putFloat("look", look)
            .putFloat("thr", thr)
            .putInt("cooldown", cooldownMs)
            .putBoolean("debug", debug)
            .apply()
    }
}

package com.example.bunnybot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

/** Sends the taps and shows the floating ON/OFF button plus the debug rings. */
class TapService : AccessibilityService() {
    companion object {
        @Volatile var instance: TapService? = null
    }

    private var wm: WindowManager? = null
    private var debugView: DebugView? = null
    private var button: TextView? = null

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Bot.load(this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        addDebugView()
        addButton()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        try {
            debugView?.let { wm?.removeView(it) }
            button?.let { wm?.removeView(it) }
        } catch (e: Exception) {
        }
        debugView = null
        button = null
        instance = null
        return super.onUnbind(intent)
    }

    fun tap() {
        val m = resources.displayMetrics
        val p = Path()
        p.moveTo(m.widthPixels * 0.5f, m.heightPixels * 0.45f)
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 25))
            .build()
        dispatchGesture(g, null, null)
    }

    fun refreshDebug() {
        debugView?.postInvalidate()
    }

    private fun addDebugView() {
        val v = DebugView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm?.addView(v, lp)
        debugView = v
    }

    private fun addButton() {
        val d = resources.displayMetrics
        val size = (64 * d.density).toInt()
        val tv = TextView(this)
        tv.gravity = Gravity.CENTER
        tv.textSize = 15f
        tv.setTextColor(Color.WHITE)
        paintButton(tv)

        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = d.widthPixels - size - 12
        lp.y = (d.heightPixels * 0.30f).toInt()

        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        tv.setOnTouchListener { v, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = ev.rawX; sy = ev.rawY; ox = lp.x; oy = lp.y; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (ev.rawX - sx).toInt()
                    val dy = (ev.rawY - sy).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) {
                        lp.x = ox + dx
                        lp.y = oy + dy
                        wm?.updateViewLayout(v, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) toggle()
                    true
                }
                else -> false
            }
        }
        wm?.addView(tv, lp)
        button = tv
    }

    private fun toggle() {
        if (!CaptureService.running) {
            Toast.makeText(this, "Open Bunny Bot and tap 'Start screen capture' first", Toast.LENGTH_LONG).show()
            return
        }
        Bot.enabled = !Bot.enabled
        button?.let { paintButton(it) }
    }

    private fun paintButton(tv: TextView) {
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(if (Bot.enabled) Color.parseColor("#CC2E8B4F") else Color.parseColor("#CCC8402C"))
        tv.background = bg
        tv.text = if (Bot.enabled) "ON" else "OFF"
    }

    /** Draws a ring on every look-ahead point. Green = path, red = fence/grass, yellow = ignored. */
    private class DebugView(ctx: Context) : View(ctx) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 4f
        }

        override fun onDraw(canvas: Canvas) {
            if (!Bot.debug) return
            val w = width.toFloat()
            val h = height.toFloat()
            for (p in Bot.probes) {
                paint.color = when (p.state) {
                    1 -> 0xFF00E676.toInt()
                    0 -> 0xFFFF1744.toInt()
                    else -> 0xFFFFEA00.toInt()
                }
                canvas.drawCircle(p.x * w, p.y * h, 14f, paint)
            }
            paint.color = Color.WHITE
            canvas.drawLine(Bot.ax * w - 22f, Bot.ay * h, Bot.ax * w + 22f, Bot.ay * h, paint)
            canvas.drawLine(Bot.ax * w, Bot.ay * h - 22f, Bot.ax * w, Bot.ay * h + 22f, paint)
        }
    }
}

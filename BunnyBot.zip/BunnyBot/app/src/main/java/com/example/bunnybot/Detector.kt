package com.example.bunnybot

import android.graphics.Color
import java.nio.ByteBuffer

/**
 * Looks at a few points ahead of the bunny. The bunny runs diagonally up-right or up-left
 * (the camera is fixed) and turns alternate. When the brown path ahead in the current
 * direction runs out, it is time to tap.
 */
class Detector {
    private var heading = 1          // +1 = up-right, -1 = up-left
    private var armed = false        // true once we have seen path ahead in the current heading
    private var cooldownUntil = 0L
    private var desyncSince = 0L
    private val hsv = FloatArray(3)

    // Direction on screen (pixel space): mostly sideways, a bit upward
    private val dirX = 0.89f
    private val dirY = 0.45f

    /** Returns true when a tap should be sent now. */
    fun process(buf: ByteBuffer, w: Int, h: Int, rs: Int, ps: Int, now: Long): Boolean {
        val list = ArrayList<Bot.Probe>()
        val fr = frac(buf, w, h, rs, ps, 1, list)
        val fl = frac(buf, w, h, rs, ps, -1, list)
        Bot.probes = list

        if (!Bot.enabled) {
            armed = false
            desyncSince = 0L
            return false
        }

        val hF = if (heading == 1) fr else fl
        val oF = if (heading == 1) fl else fr

        if (hF >= 0.6f) {
            armed = true
            desyncSince = 0L
        } else if (!armed && oF >= 0.6f && hF < 0.3f) {
            // Path is clearly on the other side: our heading guess was wrong, fix it.
            if (desyncSince == 0L) {
                desyncSince = now
            } else if (now - desyncSince > 300) {
                heading = -heading
                desyncSince = 0L
            }
        } else {
            desyncSince = 0L
        }

        if (now < cooldownUntil) return false

        if (armed && hF >= 0f && hF < Bot.thr) {
            armed = false
            heading = -heading
            cooldownUntil = now + Bot.cooldownMs
            Bot.taps++
            return true
        }
        return false
    }

    /** Share of known look-ahead points that are path, or -1 if too few are known. */
    private fun frac(buf: ByteBuffer, w: Int, h: Int, rs: Int, ps: Int, sx: Int, out: MutableList<Bot.Probe>): Float {
        var known = 0
        var path = 0
        for (i in 0 until 5) {
            val d = Bot.look + i * 0.02f
            val px = (Bot.ax * w + sx * dirX * d * w).toInt()
            val py = (Bot.ay * h - dirY * d * w).toInt()
            val st = classify(buf, w, h, rs, ps, px, py)
            out.add(Bot.Probe(px / w.toFloat(), py / h.toFloat(), st))
            if (st != 2) {
                known++
                if (st == 1) path++
            }
        }
        return if (known < 3) -1f else path.toFloat() / known
    }

    private fun classify(buf: ByteBuffer, w: Int, h: Int, rs: Int, ps: Int, x: Int, y: Int): Int {
        if (x < 1 || y < 1 || x >= w - 1 || y >= h - 1) return 2
        var r = 0
        var g = 0
        var b = 0
        for (dy in -1..1) {
            for (dx in -1..1) {
                val i = (y + dy) * rs + (x + dx) * ps
                r += buf.get(i).toInt() and 0xFF
                g += buf.get(i + 1).toInt() and 0xFF
                b += buf.get(i + 2).toInt() and 0xFF
            }
        }
        Color.RGBToHSV(r / 9, g / 9, b / 9, hsv)
        val hue = hsv[0]
        val s = hsv[1]
        val v = hsv[2]
        // Brown dirt path: hue ~26, saturation ~0.5, value ~0.36
        if (hue in 8f..45f && s > 0.28f && s < 0.8f && v > 0.18f && v < 0.62f) return 1
        // Bright orange = carrot lying on the path, ignore it
        if (hue in 5f..45f && s >= 0.65f && v >= 0.62f) return 2
        return 0
    }
}

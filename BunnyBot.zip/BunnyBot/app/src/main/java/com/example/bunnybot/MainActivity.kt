package com.example.bunnybot

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String, size: Float = 15f, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        if (bold) t.setTypeface(null, Typeface.BOLD)
        t.setPadding(0, dp(8), 0, dp(2))
        return t
    }

    private fun button(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.setOnClickListener { onClick() }
        return b
    }

    private fun slider(col: LinearLayout, name: String, min: Float, max: Float, cur: Float,
                       fmt: (Float) -> String, set: (Float) -> Unit) {
        val l = label("$name: ${fmt(cur)}")
        val s = SeekBar(this)
        s.max = 1000
        s.progress = (((cur - min) / (max - min)) * 1000).toInt().coerceIn(0, 1000)
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                val v = min + (max - min) * p / 1000f
                l.text = "$name: ${fmt(v)}"
                if (fromUser) {
                    set(v)
                    Bot.save(this@MainActivity)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        col.addView(l)
        col.addView(s)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Bot.load(this)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        }

        val scroll = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(24), dp(16), dp(24))
        scroll.addView(col)
        setContentView(scroll)

        col.addView(label("Bunny Bot", 26f, true))
        status = label("")
        col.addView(status)

        col.addView(label("Setup (once per phone restart)", 17f, true))
        col.addView(button("1. Turn on the tapper (Accessibility)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(button("2. Start screen capture") {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mpm.createScreenCaptureIntent(), 100)
        })
        col.addView(button("Stop everything") {
            stopService(Intent(this, CaptureService::class.java))
            updateStatus()
        })

        col.addView(label("Then open Bunny Runner 3D and tap the round OFF button to switch the bot on. " +
            "Rings show what the bot sees: green = path, red = fence or grass. " +
            "Drag the sliders until the white cross sits on the bunny and green rings follow the path ahead.", 14f))

        col.addView(label("Tuning", 17f, true))
        slider(col, "How far ahead to look", 0.08f, 0.35f, Bot.look, { String.format("%.2f", it) }) { Bot.look = it }
        slider(col, "Bunny position X", 0.25f, 0.75f, Bot.ax, { String.format("%.2f", it) }) { Bot.ax = it }
        slider(col, "Bunny position Y", 0.55f, 0.85f, Bot.ay, { String.format("%.2f", it) }) { Bot.ay = it }
        slider(col, "Turn sensitivity (higher = earlier)", 0.2f, 0.7f, Bot.thr, { String.format("%.2f", it) }) { Bot.thr = it }
        slider(col, "Minimum time between taps (ms)", 150f, 600f, Bot.cooldownMs.toFloat(), { it.toInt().toString() }) { Bot.cooldownMs = it.toInt() }

        val cb = CheckBox(this)
        cb.text = "Show rings on screen"
        cb.isChecked = Bot.debug
        cb.setOnCheckedChangeListener { _, checked ->
            Bot.debug = checked
            Bot.save(this)
        }
        col.addView(cb)
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        val tap = if (TapService.instance != null) "ON" else "OFF"
        val cap = if (CaptureService.running) "running" else "stopped"
        status.text = "Tapper: $tap    Screen capture: $cap"
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
            i.putExtra("code", resultCode)
            i.putExtra("data", data)
            startForegroundService(i)
            status.postDelayed({ updateStatus() }, 800)
        }
    }
}

# Bunny Bot (Android)

Watches the screen and taps for you in Bunny Runner 3D.

## Build without Android Studio (GitHub Actions)
1. Create a free GitHub account and a new empty repository.
2. Upload everything in this folder (keep the folder structure, including the hidden `.github` folder).
3. Open the repository's **Actions** tab -> **Build APK** -> **Run workflow**.
4. When it finishes, open the run and download the **bunny-bot-apk** artifact (a zip). Unzip it to get `app-debug.apk`.
5. Copy the APK to your phone and install it (allow "install unknown apps" when asked).

## First run
1. Android 13+: Settings -> Apps -> Bunny Bot -> menu (three dots) -> **Allow restricted settings**.
2. Open Bunny Bot -> "Turn on the tapper" -> find Bunny Bot tapper -> switch on.
3. Open Bunny Bot -> "Start screen capture" -> Start now.
4. Open the game. Tap the round OFF button (it turns green ON).
5. Use the rings to tune: green rings should sit on the brown path ahead of the bunny.
